clc;clear;close all;
load('B.mat')
figure();
for ii = 1:1:size(keypoints,1)
    scatter(keypoints(ii,9,1),keypoints(ii,9,2),"black","filled");
    xlim([0 imgWidth]);
    ylim([0 imgHeight]);
    set(gca,'xaxislocation','top','yaxislocation','left','ydir','reverse') % set origin position 
    hold on;
    title(sprintf("%f ms",timestampList(ii)))
    pause(1/fps)
end